<?php
/**
 * Local variables
 * @var \Phalcon\Mvc\Micro $app
 */

/**
 * Add your routes here
 */
$app->get('/', function () {
    echo $this['view']->render('index');
});

/**
 * Not found handler
 */
$app->notFound(function () {
    $this->response->setStatusCode(404, "Not Found")->sendHeaders();
    echo $this['view']->render('404');
});

$app->get('/products/{id:([0-9]+)}', function($id) {
    $prod = Product::findFirstById($id)->toArray();
    $prod['imageUrl'] = 'http://' . $_SERVER['SERVER_NAME'] . $this->url->get('img/' . $prod['imageUrl']); 
    echo json_encode($prod, JSON_NUMERIC_CHECK);
});

$app->get('/products', function() {
    $prods = Product::find()->toArray();
    foreach($prods as &$prod) {
        $prod['imageUrl'] = 'http://' . $_SERVER['SERVER_NAME'] . $this->url->get('img/' . $prod['imageUrl']); 
    }
    echo json_encode($prods, JSON_NUMERIC_CHECK);
});

$app->put('/products/rating/{id:([0-9]+)}', function($id) {
    $prod = Product::findFirstById($id);
    if(!$prod) {
        exit(json_encode(['ok' => false, 'error' => 'The product doesn\'t exist']));
    }

    $json = $this->request->getJsonRawBody();
    $prod->setRating($json->rating);

    if($prod->update()) {
        echo json_encode(['ok' => true]);
    } else {
        echo json_encode(['ok' => false, 'error' => 'Error updating the product']);
    }
});

$app->put('/products/{id:([0-9]+)}', function($id) {
    $prod = Product::findFirst('id = ' . $id);
    if(!$prod) {
        exit(json_encode(['ok' => false, 'error' => 'The product doesn\'t exist']));
    }
    
    $json = $this->request->getJsonRawBody();
    $prod->setDescription($json->description);
    $prod->setPrice($json->price);
    $prod->setAvailable($json->available);
    if(substr($json->imageUrl, 0, 4) !== "http") { // Base64
        $nombreFoto = sha1(microtime() . "_" . $id) . '.jpg';
        $rutaDir = __DIR__ . '/../public/img/';
        if(!$this->imageUtils->savePhoto($json->imageUrl, $rutaDir, $nombreFoto)) {
            exit(json_encode(['ok' => false, 'error' => 'The image could not be stored...']));
        }
        $prod->setImageUrl($nombreFoto);
    }
    
    if($prod->update()) {
        echo json_encode(['ok' => true]);
    } else {
        echo json_encode(['ok' => false, 'error' => 'Error updating the product']);
    }
});
