<?php
/**
 * Local variables
 * @var \Phalcon\Mvc\Micro $app
 */

/**
 * Add your routes here
 */
$app->get('/', function () {
    echo $this['view']->render('index');
});

/**
 * Not found handler
 */
$app->notFound(function () {
    $this->response->setStatusCode(404, "Not Found")->sendHeaders();
    echo ['ok' => false, 'error' => 'service not found'];
});

$app->get('/login', function() {
    $this->authentication->validaToken();
    return json_encode(['ok' => true]);
});

$app->post('/login', function() {
    $json = $this->request->getJsonRawBody();
    
    $user = User::findFirst(['email = ?0', 'bind' => [$json->email]]);
    
    if(!$user) {
        exit(json_encode(['ok' => false, 'error' => 'There is no user with this email.']));
    }
    
    if(!$user->getPassword()) { // Registered with google or facebook
        if($user->getIdGoogle()) {
            exit(json_encode(['ok' => false, 'error' => 'No password has been established yet. You must log in with Google\'s button.']));
        } elseif($user->getIdFacebook()) {
            exit(json_encode(['ok' => false, 'error' => 'No password has been established yet. You must log in with Facebook\'s button.']));
        }
    }
    
    if($user->getPassword() !== hash('sha256', $json->password)) { // Falla contraseña
        exit(json_encode(['ok' => false, 'error' => 'Incorrect password.']));
    }
    
    $jwt = $this->authentication->generaToken($user);

    echo json_encode(['ok' => true, 'token' => $jwt]);
});

$app->post('/login/facebook', function() {
    $authResponse = $this->request->getJsonRawBody();
                
    try {
        // Comprobamos que no hemos recibido datos falsos
        $this->facebook->setDefaultAccessToken($authResponse->accessToken);
        $response = $this->facebook->get('/me?fields=id,name,email');
        $FBuser = $response->getGraphUser();
        $picture = $this->facebook->get('/me/picture?type=large');
    } catch(Facebook\Exceptions\FacebookResponseException $e) {
        exit(json_encode(['ok' => false, 'error' => 'Graph returned an error: ' . $e->getMessage()]));
    } catch(Facebook\Exceptions\FacebookSDKException $e) {
        exit(json_encode(['ok' => false, 'error' => 'Facebook SDK returned an error: ' . $e->getMessage()]));
    }

    // https://developers.facebook.com/docs/php/GraphNode/5.0.0#user-instance-methods
    $fbId   = $FBuser->getId();
    $name = $FBuser->getName();
    $email  = $FBuser->getEmail();
    $foto   = $picture->getBody(); // Binary, copy to file!

    $user = User::findFirst(['email = ?0', 'bind' => [$email]]);

    if(!$user) { // No existe el usuario. Lo registramos
        $user = new User();
        $user->setName($name);
        $user->setEmail($email);
        $user->setIdFacebook($fbId);
        $user->setAvatar("profile.jpg");

        if(!$user->create()) {
            exit(json_encode(['ok' => false, 'error' => 'User account couldn\'t be created.']));
        }

        if($foto) {
            $user->setPhotoProfile($foto, false);  
        }
    } elseif(!$user->getIdFacebook()) {
        $user->getIdFacebook($fbId);
        $user->update();
    }

    $jwt = $this->authentication->generaToken($user);
    echo json_encode(['ok' => true, 'token' => $jwt]);
});

$app->post('/login/google', function() {
    $json = $this->request->getJsonRawBody();
    
    $googleJwt = json_decode(file_get_contents("https://www.googleapis.com/plus/v1/people/me?access_token=" . $json->access_token));

    $user = User::findFirst(['email = ?0', 'bind' => [$googleJwt->emails[0]->value]]);
    
    if(!$user) { // User doesn't exist yet (register)
        $user = new User();
        $user->setName($googleJwt->displayName);
        $user->setEmail($googleJwt->emails[0]->value);
        $user->setIdGoogle($googleJwt->id);
        $user->setAvatar("profile.jpg");

        if(!$user->create()) {
            exit(json_encode(['ok' => false, 'error' => 'User account couldn\'t be created.']));
        }

        $strfile = file_get_contents(str_replace("?sz=50", "?sz=200", $googleJwt->image->url)); 
        if($strfile) {
            $user->setPhotoProfile($strfile, false);    
        }
    } elseif(!$user->getIdGoogle()) {
        $user->getIdGoogle($googleJwt->id);
        $user->update();
    }

    $jwt = $this->authentication->generaToken($user);
    echo json_encode(['ok' => true, 'token' => $jwt]);
});

$app->post('/register', function() {
    $json = $this->request->getJsonRawBody();
    
    $userExists = User::findFirstByEmail($json->email);
    if($userExists) {
        exit(json_encode(['ok' => false, 'errores' => 'This email already exists!']));
    }
    
    $user = new User();
    $user->setName($json->name);
    $user->setEmail($json->email);
    $user->setPassword(hash('sha256',$json->password));
    $user->setAvatar('profile.jpg');
    
    if($json->avatar) {
        $user->setPhotoProfile($json->avatar, true);
    }
    
    if($user->create()) {
        echo json_encode(['ok' => true]);
    } else {
        echo json_encode(['ok' => false, 'errores' => 'User registration failed!']);
    }
    
});

$app->get('/users', function() {
    $this->authentication->validaToken();
    $users = User::find(['columns' => ['id','name','avatar','email','idGoogle','idFacebook']])->toArray();
    
    foreach ($users as $i => $user) {
        $users[$i]['avatar'] = 'http://' . $_SERVER['SERVER_NAME'] . $this->url->get('/img/user/' . $users[$i]['avatar']); 
    }
    
    echo json_encode(['users' => $users]);
});
