<?php

use Phalcon\Mvc\Model\Validator\Email as Email;

class User extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=10, nullable=false)
     */
    protected $id;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    protected $registrationDate;

    /**
     *
     * @var string
     * @Column(type="string", length=250, nullable=false)
     */
    protected $name;

    /**
     *
     * @var string
     * @Column(type="string", length=250, nullable=false)
     */
    protected $email;

    /**
     *
     * @var string
     * @Column(type="string", length=100, nullable=true)
     */
    protected $password;

    /**
     *
     * @var string
     * @Column(type="string", length=200, nullable=false)
     */
    protected $avatar;

    /**
     *
     * @var string
     * @Column(type="string", length=100, nullable=true)
     */
    protected $idGoogle;

    /**
     *
     * @var string
     * @Column(type="string", length=100, nullable=true)
     */
    protected $idFacebook;

    /**
     * Method to set the value of field id
     *
     * @param integer $id
     * @return $this
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Method to set the value of field registrationDate
     *
     * @param string $registrationDate
     * @return $this
     */
    public function setRegistrationDate($registrationDate)
    {
        $this->registrationDate = $registrationDate;

        return $this;
    }

    /**
     * Method to set the value of field name
     *
     * @param string $name
     * @return $this
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Method to set the value of field email
     *
     * @param string $email
     * @return $this
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Method to set the value of field password
     *
     * @param string $password
     * @return $this
     */
    public function setPassword($password)
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Method to set the value of field avatar
     *
     * @param string $avatar
     * @return $this
     */
    public function setAvatar($avatar)
    {
        $this->avatar = $avatar;

        return $this;
    }

    /**
     * Method to set the value of field idGoogle
     *
     * @param string $idGoogle
     * @return $this
     */
    public function setIdGoogle($idGoogle)
    {
        $this->idGoogle = $idGoogle;

        return $this;
    }

    /**
     * Method to set the value of field idFacebook
     *
     * @param string $idFacebook
     * @return $this
     */
    public function setIdFacebook($idFacebook)
    {
        $this->idFacebook = $idFacebook;

        return $this;
    }

    /**
     * Returns the value of field id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Returns the value of field registrationDate
     *
     * @return string
     */
    public function getRegistrationDate()
    {
        return $this->registrationDate;
    }

    /**
     * Returns the value of field name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Returns the value of field email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Returns the value of field password
     *
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * Returns the value of field avatar
     *
     * @return string
     */
    public function getAvatar()
    {
        return $this->avatar;
    }

    /**
     * Returns the value of field idGoogle
     *
     * @return string
     */
    public function getIdGoogle()
    {
        return $this->idGoogle;
    }

    /**
     * Returns the value of field idFacebook
     *
     * @return string
     */
    public function getIdFacebook()
    {
        return $this->idFacebook;
    }


    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'user';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return User[]
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return User
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }
    
    public function initialize() {
        $this->skipAttributes(["registrationDate"]);
    }


    public function setPhotoProfile($imgStr, $base64 = false) {
        $name = sha1(time()) . $this->id . '.jpg';
        $path = __DIR__ . '/../../public/img/user/';
        $imageUtils = $this->getDi()->getShared("imageUtils");
        
        if($imageUtils->savePhoto($imgStr, $path, $name, $base64, true, 200)) {
            $this->setAvatar($name);
            return $this->update()?true:false;
        }
        
        return false;
    }
}
