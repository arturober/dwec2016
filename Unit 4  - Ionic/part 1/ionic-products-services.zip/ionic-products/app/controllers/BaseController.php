<?php

class BaseController extends \Phalcon\Mvc\Controller {

    protected function sendError($errorMsg = false, $code = 200, $status = 'OK') {
        $data = ['ok' => false];
        if($errorMsg) {
            if(is_string($errorMsg)) {
                $data['error'] = $errorMsg;
            } elseif(is_array($errorMsg)) {
                $data['errors'] = $errorMsg;
            }
        }
        
        return $this->sendResponse($data, $code, $status);
    }
    
    protected function sendOk($data = false, $code = 200, $status = 'OK') {
        if($data && is_array($data)) {
            $data['ok'] = true;
        } else {
            $data = ['ok' => true];
        }
        
        return $this->sendResponse($data, $code, $status);
    }
    
    private function sendResponse($data, $code = 200, $status = 'OK') {
        $this->response->setStatusCode($code, $status);
        $this->response->setJsonContent($data, JSON_NUMERIC_CHECK);
        return $this->response;
    }

}
