<?php

class ProfileController extends BaseController {
    public function getMyProfile() {
        $user = User::findFirst(['id = 1']);
        
        return $this->sendOk(['user' => $user->toArray(['id', 'name', 'email', 'avatar'])]);
    }
}
