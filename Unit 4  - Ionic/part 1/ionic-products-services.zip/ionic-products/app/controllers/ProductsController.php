<?php

class ProductsController extends BaseController {
    public function getProducts() {
        return $this->sendOk(['products' => Product::find()]);
    }
    
    public function getMyProducts() {
        return $this->sendOk(['products' => Product::find('idUser = ' . 1)]);
    }
    
    public function getProduct($idProduct) {
        $prod = Product::findFirst('id = ' . $idProduct);
        $prodArray = $prod->toArray();
        $prodArray['user'] = User::findFirst(['id = ' . $prod->getIdUser()])->toArray(['name', 'email', 'avatar']);
        return $this->sendOk(['product' => $prodArray]);
    }
}
