<?php

use Phalcon\Mvc\Micro\Collection as MicroCollection;

$app->notFound(function () use ($app) {
    $app->response->setStatusCode(404, "Not Found");
    $app->response->setJsonContent(['ok' => false, 'error' => 'Service not found']);
    return $app->response;
});

/**************************************************
 *  Products collection
***************************************************/

$prods = new MicroCollection();
$prods->setPrefix('/products');

$prods->setHandler("ProductsController", true)
      ->get('/', 'getProducts')
      ->get('/my', 'getMyProducts')
      ->get('/{id:([0-9]+)}', 'getProduct');

$app->mount($prods);

/**************************************************
 *  Profile collection
***************************************************/

$profile = new MicroCollection();
$profile->setPrefix('/profile');

$profile->setHandler("ProfileController", true)
      ->get('/', 'getMyProfile');

$app->mount($profile);

/**************************************************
 *  Comments collection
***************************************************/

$comments = new MicroCollection();
$comments->setPrefix('/comments');

$comments->setHandler("CommentsController", true)
      ->get('/product/{id:([0-9]+)}', 'getComments');

$app->mount($comments);
