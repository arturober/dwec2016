<?php

use Phalcon\Mvc\Micro\Collection as MicroCollection;

$app->notFound(function () use ($app) {
    $app->response->setStatusCode(404, "Not Found");
    $app->response->setJsonContent(['ok' => false, 'error' => 'Service not found']);
    return $app->response;
});

$app->before(function() use($app) {
    if(strncmp($app->router->getRewriteUri(), "/auth", 5)) { // Needs token
        $error = $app->authentication->validaToken();
        if($error) {
            $app->response->setStatusCode(403, "Not Authenticated");
            $app->response->setContent(json_encode(['ok' => false, 'error' => $error]));
            $app->response->send();
            return false;
        }
    }
    
    return true;
});

/**************************************************
 *  Authentication collection
***************************************************/

$auth = new MicroCollection();
$auth->setPrefix('/auth');

$auth->setHandler("AuthController", true)
     ->post('/login', 'login')
     ->post('/register', 'register')
     ->get('/token', 'tokenValidation');

$app->mount($auth); 

/**************************************************
 *  Products collection
***************************************************/

$prods = new MicroCollection();
$prods->setPrefix('/products');

$prods->setHandler("ProductsController", true)
      ->get('/', 'getProducts')
      ->get('/my', 'getMyProducts')
      ->get('/{id:([0-9]+)}', 'getProduct')
      ->post('/', 'createProduct')
      ->delete('/{id:([0-9]+)}', 'deleteProduct');

$app->mount($prods);

/**************************************************
 *  Profile collection
***************************************************/

$profile = new MicroCollection();
$profile->setPrefix('/profile');

$profile->setHandler("ProfileController", true)
      ->get('/', 'getMyProfile')
      ->post('/password', 'changePassword');

$app->mount($profile);

/**************************************************
 *  Comments collection
***************************************************/

$comments = new MicroCollection();
$comments->setPrefix('/comments');

$comments->setHandler("CommentsController", true)
      ->get('/product/{id:([0-9]+)}', 'getComments');

$app->mount($comments);
