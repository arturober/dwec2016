<?php

class ProfileController extends BaseController {
    public function getMyProfile() {
        $user = User::findFirst(['id = 1']);
        
        return $this->sendOk(['user' => $user->toArray(['id', 'name', 'email', 'avatar'])]);
    }
    
    public function changePassword() {
        $token = $this->authentication->getDecodedToken();
        $json = $this->request->getJsonRawBody();
        
        $user = User::findFirst('id = ' . $token->id, false);
        $user->setPassword(hash('sha256', $json->password));
        
        if($user->update()) {
            return $this->sendOk();
        } else {
            return $this->sendError("Error updating the password");
        }
    }
}
