<?php

class ProductsController extends BaseController {
    public function getProducts() {
        return $this->sendOk(['products' => Product::find(['order' => 'available DESC'])]);
    }
    
    public function getMyProducts() {
        $token = $this->authentication->getDecodedToken();
        return $this->sendOk(['products' => Product::find(['idUser = ' . $token->id, 'order' => 'available DESC'])]);
    }
    
    public function getProduct($idProduct) {
        $prod = Product::findFirst('id = ' . $idProduct);
        $prodArray = $prod->toArray();
        $prodArray['user'] = User::findFirst(['id = ' . $prod->getIdUser()])->toArray(['name', 'email', 'avatar']);
        return $this->sendOk(['product' => $prodArray]);
    }
    
    public function createProduct() {
        $token = $this->authentication->getDecodedToken();
        $json = $this->request->getJsonRawBody();
        
        $prod = new Product();
        $prod->setIdUser($token->id);
        $prod->setDescription($json->description);
        $prod->setPrice($json->price);
        $prod->setRating(0);
        
        if(isset($json->imageUrl) && $json->imageUrl != "") {
            $name = sha1(microtime() . "_" . $token->id) . '.jpg';
            $dir = __DIR__ . '/../../public/img/products/';
            
            if(!$this->imageUtils->savePhoto($json->imageUrl, $dir, $name, true, true, "512")) {
                return $this->sendError("Error saving the image");
            }
            
            $prod->setImageUrl($name);
        } else {
            $prod->setImageUrl("product.png");
        }
        
        if($prod->create()) {
            return $this->sendOk(['product' => Product::findFirst('id = ' . $prod->getId())]);
        } else {
            return $this->sendError("Error creating the product");
        }
    }
    
    public function deleteProduct($id) {
        $token = $this->authentication->getDecodedToken();
        
        $prod = Product::findFirst('id = ' . $id);
        if(!$prod) {
            return $this->sendError("This product doesn't exist");
        }
        
        if($prod->getIdUser() != $token->id) {
            return $this->sendError("You can't delete other user's products");
        }
        
        if($prod->delete()) {
            return $this->sendOk();
        } else {
            return $this->sendError("Error deleting the product");
        }
    }
}
