<?php


/**
 * Description of AuthController
 *
 * @author arturo
 */
class AuthController extends BaseController {
     public function login() {
        $json = $this->request->getJsonRawBody();

        $user = User::findFirst(['email = ?0', 'bind' => [$json->email]]);

        if (!$user) {
            return $this->sendError('There is no user with this email.');
        }

        if (!$user->getPassword()) { // Registered with google or facebook
            if ($user->getIdGoogle()) {
                return $this->sendError('No password has been established yet. You must log in with Google\'s button.');
            } elseif ($user->getIdFacebook()) {
                return $this->sendError('No password has been established yet. You must log in with Facebook\'s button.');
            }
        }

        if ($user->getPassword() !== hash('sha256', $json->password)) { // Falla contraseña
            return $this->sendError('Incorrect password.');
        }

        $jwt = $this->authentication->generaToken($user);

        return $this->sendOk(['token' => $jwt]);
    }
    
    public function register() {
        $json = $this->request->getJsonRawBody();
    
        $userExists = User::findFirstByEmail($json->email);
        if($userExists) {
            return $this->sendError('This email already exists!');
        }

        $user = new User();
        $user->setName($json->name);
        $user->setEmail($json->email);
        $user->setPassword(hash('sha256',$json->password));
        $user->setAvatar('profile.jpg');

//        if($json->photo) {
//            $user->setPhotoProfile($json->photo, true);
//        }

        if($user->create()) {
            return $this->sendOk();
        } else {
            return $this->sendError('User registration failed!');
        }
    }

    public function tokenValidation() {
        $error = $this->authentication->validaToken();
        if(!$error) {
            return $this->sendOk();
        } else {
            return $this->sendError($error);
        }
    }
}
