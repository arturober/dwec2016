<?php

/**
 * Description of Authentication
 *
 * @author arturo
 */
class Authentication extends Phalcon\Mvc\User\Component {
    
    private $decodedToken = null;
    
    public function getDecodedToken() {
        return $this->decodedToken;
    }
    /**
     * Valida que en la cabecera HTTP "Authentication" haya aun token de autenticación válido
     * @return Mensaje de error
     */
    public function validaToken() {
        $error = '';
        
        if(!array_key_exists('Authorization',getallheaders())) {
            $error = 'No se ha iniciado sesión en la aplicación';
        } else {
            $authorization = getallheaders()['Authorization'];
            $trozos = explode(' ', $authorization);
            $auth = $trozos[1];
            try {
                $decoded = \Firebase\JWT\JWT::decode($auth, base64_decode($this->config->application->jwtKey), ['HS256']);
            } catch(\Firebase\JWT\SignatureInvalidException $e) {
                $error = 'No se ha iniciado sesión en la aplicación';
            } catch(\Firebase\JWT\ExpiredException $e) {
                $error = 'La sesión ha caducado';
            }
        }
        
        if($error === '') {
            $this->decodedToken = $decoded;
        }
       
        return $error;
    }
    
    /**
     * Genera un token para la autenticación del usuario en la aplicación
     * @param $usuario Objeto del modelo con los datos del usuario autenticado
     * @return Token generado con JWT. Caduca al mes.
     */
    public function generaToken(User $usuario) {
        $tiempo = time();
        
        $token = \Firebase\JWT\JWT::encode(
            [
                'exp' => $tiempo + 60*60*24*30, // Caduca a los 30 días
                'id' => $usuario->getId(), 
                'name' => $usuario->getName(), 
                'email' => $usuario->getEmail(),
            ], 
            base64_decode($this->config->application->jwtKey), // Clave JWT
            'HS256'     // Algoritmo de codificación del token
        );
        
        return $token;
    }
    
    public function renuevaToken() {
        $decoded = $this->decodedToken;
        
        if(!$decoded || $decoded->id < 0) {
            return null;
        }
        
        $tiempo = time();
        
        $token = \Firebase\JWT\JWT::encode(
            [
                'iat' => $tiempo, // Fecha y hora que se genera el token
                'exp' => $tiempo + 60*60*24*30, // Caduca a los 30 días
                'id' => $decoded->id, 
                'name' => $decoded->name, 
                'email' => $decoded->email
            ], 
            base64_decode($this->config->application->jwtKey), // Clave JWT
            'HS256'     // Algoritmo de codificación del token
        );
        
        $this->decodedToken = $token;
        return $token;
    }
}
